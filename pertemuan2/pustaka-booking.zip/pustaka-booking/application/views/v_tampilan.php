<html>
    <head>
        <title>Contoh Tampilan</title> 
</head>

    <body>
        <h1>Hola!</h1>
        <p>This is a tester</p>
</body>
</html>