<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Home extends CI_Controller {

	public function index()
	{
		$this->load->view('v_tampilan');
	}

	public function example1()
	{
		echo"Ini tampilan controller home function example1";
	}

	public function tampilan_view()
	{
		$this->load->view('v_tampilan');
	}
}
